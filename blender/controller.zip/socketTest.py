# -*- coding: utf-8 -*-
"""
Created on Mon Jun 24 14:48:53 2013

@author: Jak
"""

import SocketServer

def main():
    HOST, PORT = "localhost", 8080

    # Create the server, binding to localhost on port 9999
    server = SocketServer.TCPServer((HOST, PORT), EchoHandler)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
    
    
class EchoHandler(SocketServer.StreamRequestHandler):
    """Prints messages from a socket(blender)"""
    def setup(self):
        print('{}:{} connected'.format(*self.client_address))

    def handle(self):
        while True:
            data = self.request.recv(4096)
            print data
            if not data: break
            #self.request.sendall(data)

    def finish(self):
        print('{}:{} disconnected'.format(*self.client_address))


    
if __name__=="__main__":
    main()