# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 16:11:15 2013

@author: Jak
"""
import SocketServer

import conn

    
    
class MsgPasser(SocketServer.StreamRequestHandler):
    """
    Passes messages from a socket (blender) to a uC
    """
    started = False    
    
    def start(self):
        print self.started
        if not self.started:
            self.th = conn.ThreadHelper(conn.SerialProtocol, conn.message)
            self.th.protocol.connect()
            self.th.startThread()
            self.started = True
        print self.started

    def setup(self):
        self.start()
        print('{}:{} connected'.format(*self.client_address))
        

    def handle(self):
        while True:
            data = self.request.recv(4096)
            for x in data.split("|"):
                self.th.q.put(x)
            self.th.q.put(data)
            if not data: break
            #self.request.sendall(data)

    def finish(self):
        print('{}:{} disconnected'.format(*self.client_address))


def main():
    HOST, PORT = "localhost", 8080

    # Create the server, binding to localhost on port 9999
    server = SocketServer.TCPServer((HOST, PORT), MsgPasser)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
    
    
if __name__ == "__main__":
    main()