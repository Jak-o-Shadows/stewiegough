# -*- coding: utf-8 -*-
"""
Created on Tue Jul 09 17:15:30 2013

@author: Jak

Handles the connection and queues and threading

"""

import socket
import threading
import time
#import io
import sys

class Protocol():
    """Implements the actual send/recieve interface"""
    def __init__(self):
        pass
    

def message(data):
    """Converts some data into the stuff that gets sent over the connection
    Can replace me! Use if changing line ending for example.
    Copy the bytes(str(data)+ etc), etc though
    """
    
    try:
        return bytes(str(data) + ";", "utf-8")
    except TypeError:
        return bytes(str(data) + ";")
    
if sys.version_info.major >2:
    import queue   
    class BluetoothProtocol():
        """Connects to a bluetooth to serial adaptor"""
        def __init__(self):
            self.MAC = "00:00:00:00:00:00"
            self.port = 3
        
        def connect(self):
            #self.con = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)
            self.con = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)
            self.con.connect((self.MAC, self.port))
            
        def send(self, msg):
            self.con.send(msg)
            
        def read(self):
            pass
else:
    import Queue as queue
            

try:
    import serial
    class SerialProtocol(Protocol):
        """Serial protocol, defaults to COM3 and 9600br"""
        def __init__(self):
            self.port = "COM3"
            self.baudrate = 9600
            
            self.eol = "\n"
        
        def connect(self):
            self.ser = serial.Serial(port=self.port, baudrate=self.baudrate)
            #self.sio = io.TextIOWrapper(io.BufferedRWPair(self.ser, self.ser, newline=self.eol))
        
        def send(self, msg):
            #self.sio.write(unicode(msg))
            self.ser.write(unicode(msg))
        
        def read(self):
            pass
except ImportError:
    pass

class SocketProtocol(Protocol):
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.address = ("localhost", 8080)
              
        
    def connect(self):
        self.sock.connect(self.address)
        
    def send(self, msg):
        self.sock.send(msg)
        
    def read(self):
        l = self.sock.recv(4096)
        
        
class ThreadHelper():
    def __init__(self, protocol, message):
        self.q = queue.Queue()
        self.protocol = protocol()
        self.msg = message
        
    def startThread(self):
        t = threading.Thread(target=self.thread)
        t.daemon = True
        t.start()
    
    def thread(self):
        keepGoing = True
        while keepGoing:
            item = self.q.get()
            self.protocol.send(self.msg(item))
            time.sleep(0.001)
            self.q.task_done()
        
def main():
    th = ThreadHelper(SocketProtocol, message)
    th.protocol.connect()
    th.q.put("sfsdf")
    th.startThread()
    #socketConn = SocketProtocol()
    #socketConn.connect()
    #while 1:
    #    socketConn.send("s")



if __name__ == "__main__":
    main()